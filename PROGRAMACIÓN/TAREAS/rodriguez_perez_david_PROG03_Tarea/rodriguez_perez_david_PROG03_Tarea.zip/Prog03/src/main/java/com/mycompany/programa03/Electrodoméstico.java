/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.programa03;
/**
 *
 * @author David Rodríguez Pérez
 * // En esta clase se crea la clase Electrodoméstico con sus diferentes métodos y propiedades
 */
public class Electrodoméstico {

    //se inicializan las propiedades de la clase
    private String numSerie;
    private String marca;
    private int precio;
    private final int iva = 21;
    private int descuento;

    //constructor por defecto
    public Electrodoméstico() {
        this.marca = "";
        this.numSerie = "pendiente de asignar";
        this.precio = 0;
    }

    //contructor con parámetros
    public Electrodoméstico(String numSerie, String marca, int precio) {
        this.marca = marca;
        this.numSerie = numSerie;
        this.precio = precio;
    }

    //setters
    public void SetMarca(String marca) {
        this.marca = marca;
    }

    public void SetPrecio(int precio) {
        this.precio = precio;
    }

    public void SetNumSerie(String numSerie) {
        this.numSerie = numSerie;
    }

    //getters
    public String GetMarca() {
        return this.marca;
    }

    public String GetNumSerie() {
        return this.numSerie;
    }

    public int GetPrecio() {
        return this.precio;
    }

    //aplicar IVA
    public void aplicarIva() {
        int total = ((this.precio * iva) / 100) + this.precio;
        this.precio = total;
    }

    //descuento
    public void rebajar_precio(int descuento) {
        int total = this.precio - ((this.precio * descuento) / 100);

        if (total < 10) {
            total = 10;
        }

        this.precio = total;
    }

    //metodo cadena
    public String getTodo() {
        String cadena = this.numSerie + "," + this.marca + "," + this.precio + "€";
        return cadena;
    }
}
