/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.programa03;

import com.mycompany.programa03.Electrodoméstico;

/**
 *
 * @author David Rodríguez Pérez
 */
public class principal {

    public static void main(String[] args) {
        //contructor por defecto
        Electrodoméstico e1 = new Electrodoméstico();

        Electrodoméstico e2 = new Electrodoméstico();
        e2.SetNumSerie("123-456-789-xyz");
        e2.SetMarca("MSI");
        e2.SetPrecio(100);

        System.out.println("El número de Serie del electrodoméstico 1 es " + e1.GetNumSerie() + " y su marca " + e1.GetMarca());
        System.out.println("El número de Serie del electrodoméstico 2 es " + e2.GetNumSerie() + " y su marca " + e2.GetMarca());

        //modificación del e1
        e1.SetNumSerie("987-654-321-XYZ");
        e1.SetMarca("Siemens");

        System.out.println("Valores almacenados para  electrodoméstico 1: " + e1.getTodo());

        //aplicar iva a e2 y descuentos
        e2.aplicarIva();
        System.out.println("El precio actual de e2 + IVA es  " + e2.GetPrecio() + "€");

        int rebaja1 = 20;
        e2.rebajar_precio(rebaja1);

        System.out.println("El precio actual de e2 tras una rebaja del " + rebaja1 + "% es: " + e2.GetPrecio() + "€");

        int rebaja2 = 27;
        e2.rebajar_precio(rebaja2);

        System.out.println("El precio actual de e2 tras una rebaja del " + rebaja2 + "% es: " + e2.GetPrecio() + "€");

        int rebaja3 = 34;
        e2.rebajar_precio(rebaja3);

        System.out.println("El precio actual de e2 tras una rebaja del " + rebaja3 + "% es: " + e2.GetPrecio() + "€");

        int rebaja4 = 54;
        e2.rebajar_precio(rebaja3);

        System.out.println("El precio actual de e2 tras una rebaja del " + rebaja4 + "% es: " + e2.GetPrecio() + "€");

        int rebaja5 = 50;
        e2.rebajar_precio(rebaja5);

        System.out.println("El precio actual de e2 tras una rebaja del " + rebaja5 + "% es: " + e2.GetPrecio() + "€");

        int rebaja6 = 90;
        e2.rebajar_precio(rebaja6);

        System.out.println("El precio actual de e2 tras una rebaja del " + rebaja6 + "% es: " + e2.GetPrecio() + "€");

    }
}
