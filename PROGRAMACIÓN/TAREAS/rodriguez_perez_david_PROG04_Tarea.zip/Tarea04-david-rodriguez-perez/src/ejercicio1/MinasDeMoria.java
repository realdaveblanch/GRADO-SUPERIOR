/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio1;
import java.util.Scanner;
/**
 *
 * @author David Rodríguez Pérez
 */
public class MinasDeMoria {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String password = "mellon";
        String entrada;
      
        int intentos = 3;

        while(intentos > 0){
            try{
                System.out.println( intentos + " intentos.");
                System.out.println("Ingresa la contraseña correcta:");
                entrada = teclado.nextLine();
                    
                    if(entrada.equals("")){
                        System.out.println("La contraseña no puede estar vacía.");
                        continue;
                    }
                    if (!entrada.equals(password)){
                        System.out.println("¡Eso no es élfico! Inténtalo de nuevo.");
                        intentos--;
                        System.out.println("Te quedan " + intentos + " intentos.");

                    }else{
                        System.out.println("¡Las puertas se abren con un rechinar y entras a las Minas de Moria!");
                           break;
                    }

            }catch(Exception e){
                System.out.println("Ocurrió un error al ingresar la contraseña. Inténtalo de nuevo.");
            }

        }
        if(intentos == 0){
            System.out.println("Las puertas se cierran para siempre.");
        }
        
    }
}
