/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio2;

import java.util.Scanner;
import ejercicio2.JediHelper;
import java.util.InputMismatchException;
/**
 *
 * @author David Rodríguez Pérez
 */
public class SistemaJedi {
    public static void main(String[] args) {
        try {
            Scanner entrada = new Scanner(System.in);
            JediHelper helper = new JediHelper();
            int opcion = 0;
            int argumento;
            
            while(opcion != 4){
                
                try{
                    System.out.println("======= MENU JEDI ========");
                    System.out.println("1. Entrenar con el sable láser.");
                    System.out.println("2. Mapear la Galaxia.");
                    System.out.println("3. Analizar midiclorianos.");
                    System.out.println("4. Apagar el Holocrón.");

                    opcion = entrada.nextInt();
                        switch (opcion) {
                            case 1:
                                System.out.println("Introduce el nivel de entrenamiento:");
                                argumento = entrada.nextInt();
                                helper.entrenarSable(argumento);
                                break;

                            case 2:
                                System.out.println("Introduce el límite de sistemas a mapear:");
                                argumento = entrada.nextInt();
                                helper.mapearGalaxia(argumento);
                                break;

                            case 3:
                                helper.analizar();
                                break;

                            case 4:
                                break;

                            default:
                                System.out.println("Opción no válida.");
                        }
                    
                    }catch (InputMismatchException e) {
                        System.out.println("La opción debe ser numérica!");
                }
            
            }
            
        }catch(Exception e){
                System.out.println("Ocurrió un error inesperado: "+ e);    
        }
  
    }
}
