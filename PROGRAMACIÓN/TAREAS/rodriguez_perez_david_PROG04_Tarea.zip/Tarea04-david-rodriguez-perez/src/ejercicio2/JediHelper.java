/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio2;
import java.util.Scanner;
/**
 *
 * @author David Rodríguez Pérez
 */
public class JediHelper {
    
    public void entrenarSable(int numero){
        int resultado;
        for (int i = 1; i < 11; i++) {
            resultado = i*numero;
            System.out.println(i + "x" + numero + " = " + resultado);
        }
    }
    
    public void mapearGalaxia(int numero){
        System.out.println("Mapeando sistemas estelares: ");
        for (int i = 1; i < numero +1; i++) {
            
            if(i % 2 == 0){
                System.out.println("Sistema #" + i);
            }
        }
    }
    
     public void analizar() {
        Scanner scanner = new Scanner(System.in);
        int suma = 0;
        int contador = 0;
        int midiclorianos;

        System.out.println("Ingrese el conteo de midiclorianos (-1 para terminar de insertar datos):");
        
        // Pedir números hasta que el usuario ingrese -1
        while (true) {
            midiclorianos = scanner.nextInt();
            if (midiclorianos == -1) {
                break; // Terminar si se ingresa -1
            }
            suma += midiclorianos; // Acumulamos el total
            contador++; // Contamos cuántos números se ingresaron
        }

        if (contador > 0) {
            double promedio = (double) suma / contador; // Calculamos el promedio
            System.out.println("El promedio de los midiclorianos es: " + promedio);
        } else {
            System.out.println("No se ingresaron valores válidos.");
        }
    }
    
}
